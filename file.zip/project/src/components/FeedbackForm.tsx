import React, { useState } from 'react';
import { Star } from 'lucide-react';
import type { Teacher, FeedbackData } from '../App';

interface FeedbackFormProps {
  teacher: Teacher;
  onSubmit: (data: FeedbackData) => void;
}

function FeedbackForm({ teacher, onSubmit }: FeedbackFormProps) {
  const [ratings, setRatings] = useState({
    teachingQuality: 0,
    communication: 0,
    preparedness: 0,
    helpfulness: 0,
    overallRating: 0,
  });
  const [comments, setComments] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...ratings,
      comments,
    });
  };

  const RatingInput = ({ name, label }: { name: keyof typeof ratings; label: string }) => (
    <div className="mb-6">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label}
      </label>
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setRatings({ ...ratings, [name]: value })}
            className="focus:outline-none"
          >
            <Star
              className={`w-8 h-8 ${
                value <= ratings[name]
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <form onSubmit={handleSubmit}>
      <h2 className="text-xl font-semibold mb-6">
        Provide Feedback for {teacher.name}
      </h2>
      <p className="text-gray-600 mb-6">
        {teacher.department} • {teacher.subject}
      </p>

      <RatingInput name="teachingQuality" label="Teaching Quality" />
      <RatingInput name="communication" label="Communication Skills" />
      <RatingInput name="preparedness" label="Class Preparedness" />
      <RatingInput name="helpfulness" label="Helpfulness" />
      <RatingInput name="overallRating" label="Overall Rating" />

      <div className="mb-6">
        <label
          htmlFor="comments"
          className="block text-sm font-medium text-gray-700 mb-2"
        >
          Additional Comments
        </label>
        <textarea
          id="comments"
          rows={4}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          value={comments}
          onChange={(e) => setComments(e.target.value)}
        />
      </div>

      <button
        type="submit"
        className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
      >
        Submit Feedback
      </button>
    </form>
  );
}

export default FeedbackForm;