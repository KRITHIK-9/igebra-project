import React from 'react';
import { Star, RefreshCw, TrendingUp, BarChart3, PieChart } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  ArcElement,
} from 'chart.js';
import { Bar, Radar, Doughnut } from 'react-chartjs-2';
import type { Teacher, FeedbackData } from '../App';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  ArcElement
);

interface FeedbackReportProps {
  teacher: Teacher;
  feedback: FeedbackData;
  onReset: () => void;
}

function FeedbackReport({ teacher, feedback, onReset }: FeedbackReportProps) {
  const categories = [
    { key: 'teachingQuality', label: 'Teaching Quality' },
    { key: 'communication', label: 'Communication Skills' },
    { key: 'preparedness', label: 'Class Preparedness' },
    { key: 'helpfulness', label: 'Helpfulness' },
    { key: 'overallRating', label: 'Overall Rating' },
  ];

  // Mock historical data for AI analysis
  const historicalData = {
    teachingQuality: [4.2, 4.5, 4.3, feedback.teachingQuality],
    communication: [4.0, 4.2, 4.1, feedback.communication],
    preparedness: [4.3, 4.4, 4.2, feedback.preparedness],
    helpfulness: [4.1, 4.3, 4.4, feedback.helpfulness],
    overallRating: [4.2, 4.3, 4.3, feedback.overallRating],
  };

  // Calculate improvement trends
  const trends = categories.map(({ key, label }) => {
    const history = historicalData[key as keyof typeof historicalData];
    const currentValue = history[history.length - 1];
    const previousValue = history[history.length - 2];
    const improvement = ((currentValue - previousValue) / previousValue) * 100;
    return {
      label,
      improvement: improvement.toFixed(1),
      trend: improvement >= 0 ? 'positive' : 'negative',
    };
  });

  // Bar chart data
  const barChartData = {
    labels: categories.map(c => c.label),
    datasets: [
      {
        label: 'Current Rating',
        data: categories.map(c => feedback[c.key as keyof FeedbackData]),
        backgroundColor: 'rgba(79, 70, 229, 0.8)',
        borderColor: 'rgba(79, 70, 229, 1)',
        borderWidth: 1,
      },
      {
        label: 'Previous Average',
        data: categories.map(c => {
          const history = historicalData[c.key as keyof typeof historicalData];
          return history[history.length - 2];
        }),
        backgroundColor: 'rgba(156, 163, 175, 0.5)',
        borderColor: 'rgba(156, 163, 175, 1)',
        borderWidth: 1,
      },
    ],
  };

  // Radar chart data
  const radarChartData = {
    labels: categories.map(c => c.label),
    datasets: [
      {
        label: 'Performance Metrics',
        data: categories.map(c => feedback[c.key as keyof FeedbackData]),
        backgroundColor: 'rgba(79, 70, 229, 0.2)',
        borderColor: 'rgba(79, 70, 229, 1)',
        borderWidth: 2,
      },
    ],
  };

  // Doughnut chart data for overall rating distribution
  const doughnutChartData = {
    labels: ['Excellent', 'Good', 'Average', 'Below Average', 'Poor'],
    datasets: [
      {
        data: [40, 30, 20, 7, 3], // Mock distribution data
        backgroundColor: [
          'rgba(34, 197, 94, 0.8)',
          'rgba(79, 70, 229, 0.8)',
          'rgba(234, 179, 8, 0.8)',
          'rgba(249, 115, 22, 0.8)',
          'rgba(239, 68, 68, 0.8)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const RatingDisplay = ({ rating }: { rating: number }) => (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((value) => (
        <Star
          key={value}
          className={`w-5 h-5 ${
            value <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
          }`}
        />
      ))}
    </div>
  );

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2">AI-Enhanced Feedback Report</h2>
        <p className="text-gray-600">
          {teacher.name} • {teacher.department} • {teacher.subject}
        </p>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-lg p-6 shadow-md">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Performance Comparison
          </h3>
          <div className="h-64">
            <Bar
              data={barChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    max: 5,
                  },
                },
              }}
            />
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-md">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <PieChart className="w-5 h-5" />
            Skill Distribution
          </h3>
          <div className="h-64">
            <Radar
              data={radarChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  r: {
                    beginAtZero: true,
                    max: 5,
                  },
                },
              }}
            />
          </div>
        </div>
      </div>

      {/* Trend Analysis */}
      <div className="bg-white rounded-lg p-6 shadow-md mb-8">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Performance Trends
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {trends.map((item) => (
            <div
              key={item.label}
              className="p-4 rounded-lg bg-gray-50"
            >
              <h4 className="font-medium text-sm text-gray-600">{item.label}</h4>
              <p className={`text-lg font-semibold ${
                item.trend === 'positive' ? 'text-green-600' : 'text-red-600'
              }`}>
                {item.trend === 'positive' ? '+' : ''}{item.improvement}%
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Rating Distribution */}
      <div className="bg-white rounded-lg p-6 shadow-md mb-8">
        <h3 className="text-lg font-semibold mb-4">Overall Rating Distribution</h3>
        <div className="h-64">
          <Doughnut
            data={doughnutChartData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
            }}
          />
        </div>
      </div>

      {/* Detailed Ratings */}
      <div className="bg-gray-50 rounded-lg p-6 mb-6">
        <h3 className="text-lg font-semibold mb-4">Detailed Ratings</h3>
        {categories.map(({ key, label }) => (
          <div
            key={key}
            className="flex items-center justify-between py-3 border-b last:border-b-0 border-gray-200"
          >
            <span className="font-medium">{label}</span>
            <RatingDisplay rating={feedback[key as keyof FeedbackData] as number} />
          </div>
        ))}
      </div>

      {/* Comments Section */}
      {feedback.comments && (
        <div className="mb-8">
          <h3 className="font-medium mb-2">Additional Comments</h3>
          <p className="text-gray-600 bg-gray-50 p-4 rounded-lg">
            {feedback.comments}
          </p>
        </div>
      )}

      {/* Action Button */}
      <button
        onClick={onReset}
        className="flex items-center justify-center gap-2 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
      >
        <RefreshCw className="w-4 h-4" />
        Submit Another Feedback
      </button>
    </div>
  );
}

export default FeedbackReport;