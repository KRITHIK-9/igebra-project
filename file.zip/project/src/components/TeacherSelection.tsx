import React from 'react';
import { ChevronRight } from 'lucide-react';
import type { Teacher } from '../App';

const teachers: Teacher[] = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    department: "Computer Science",
    subject: "Data Structures"
  },
  {
    id: 2,
    name: "Prof. Michael Chen",
    department: "Mathematics",
    subject: "Linear Algebra"
  },
  {
    id: 3,
    name: "Dr. Emily Williams",
    department: "Physics",
    subject: "Quantum Mechanics"
  },
  {
    id: 4,
    name: "Prof. David Brown",
    department: "Computer Science",
    subject: "Web Development"
  }
];

interface TeacherSelectionProps {
  onSelect: (teacher: Teacher) => void;
}

function TeacherSelection({ onSelect }: TeacherSelectionProps) {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">Select a Teacher</h2>
      <div className="grid gap-4">
        {teachers.map((teacher) => (
          <button
            key={teacher.id}
            onClick={() => onSelect(teacher)}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-indigo-50 transition-colors border border-gray-200"
          >
            <div>
              <h3 className="font-medium text-lg">{teacher.name}</h3>
              <p className="text-gray-600">
                {teacher.department} • {teacher.subject}
              </p>
            </div>
            <ChevronRight className="text-gray-400" />
          </button>
        ))}
      </div>
    </div>
  );
}

export default TeacherSelection;