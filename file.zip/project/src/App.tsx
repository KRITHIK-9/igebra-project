import React, { useState } from 'react';
import { ChevronRight, FileCheck, UserRound, Star, StarHalf } from 'lucide-react';
import TeacherSelection from './components/TeacherSelection';
import FeedbackForm from './components/FeedbackForm';
import FeedbackReport from './components/FeedbackReport';

export type Teacher = {
  id: number;
  name: string;
  department: string;
  subject: string;
};

export type FeedbackData = {
  teachingQuality: number;
  communication: number;
  preparedness: number;
  helpfulness: number;
  overallRating: number;
  comments: string;
};

function App() {
  const [step, setStep] = useState<number>(1);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);
  const [feedbackData, setFeedbackData] = useState<FeedbackData | null>(null);

  const handleTeacherSelect = (teacher: Teacher) => {
    setSelectedTeacher(teacher);
    setStep(2);
  };

  const handleFeedbackSubmit = (data: FeedbackData) => {
    setFeedbackData(data);
    setStep(3);
  };

  const handleReset = () => {
    setStep(1);
    setSelectedTeacher(null);
    setFeedbackData(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-indigo-600 text-white py-6 px-4 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <UserRound className="w-8 h-8" />
          <h1 className="text-2xl font-bold">Teacher Feedback System</h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {[1, 2, 3].map((number) => (
              <div
                key={number}
                className={`flex items-center ${
                  number !== 3 ? 'flex-1' : ''
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    step >= number
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {number}
                </div>
                {number !== 3 && (
                  <div className="flex-1 h-1 mx-2 bg-gray-200">
                    <div
                      className={`h-full ${
                        step > number ? 'bg-indigo-600' : 'bg-gray-200'
                      }`}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-sm text-gray-600">
            <span>Select Teacher</span>
            <span>Provide Feedback</span>
            <span>View Report</span>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          {step === 1 && <TeacherSelection onSelect={handleTeacherSelect} />}
          {step === 2 && selectedTeacher && (
            <FeedbackForm
              teacher={selectedTeacher}
              onSubmit={handleFeedbackSubmit}
            />
          )}
          {step === 3 && selectedTeacher && feedbackData && (
            <FeedbackReport
              teacher={selectedTeacher}
              feedback={feedbackData}
              onReset={handleReset}
            />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;